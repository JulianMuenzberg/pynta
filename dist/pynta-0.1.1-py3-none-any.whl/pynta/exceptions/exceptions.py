class PublisherNotStarted(Exception):
    pass